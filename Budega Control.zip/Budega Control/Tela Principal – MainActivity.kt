package com.example.budegacontrol

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.budegacontrol.models.Product
import com.google.firebase.database.*

class MainActivity : AppCompatActivity() {
    private lateinit var dbRef: DatabaseReference
    private lateinit var recyclerView: RecyclerView
    private val productList = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)

        dbRef = FirebaseDatabase.getInstance().getReference("products")

        dbRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                productList.clear()
                for (item in snapshot.children) {
                    val product = item.getValue(Product::class.java)
                    product?.let { productList.add(it) }
                }
                recyclerView.adapter = ProductAdapter(productList)
            }

            override fun onCancelled(error: DatabaseError) {}
        })

        findViewById<View>(R.id.btnAddProduct).setOnClickListener {
            startActivity(Intent(this, AddProductActivity::class.java))
        }

        findViewById<View>(R.id.btnRegisterSale).setOnClickListener {
            startActivity(Intent(this, RegisterSaleActivity::class.java))
        }
    }
}
