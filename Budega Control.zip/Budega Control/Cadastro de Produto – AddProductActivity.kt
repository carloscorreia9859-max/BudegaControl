package com.example.budegacontrol

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.budegacontrol.models.Product
import com.google.firebase.database.FirebaseDatabase

class AddProductActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        val name = findViewById<EditText>(R.id.etName)
        val price = findViewById<EditText>(R.id.etPrice)
        val stock = findViewById<EditText>(R.id.etStock)
        val btnSave = findViewById<Button>(R.id.btnSave)

        btnSave.setOnClickListener {
            val dbRef = FirebaseDatabase.getInstance().getReference("products")
            val id = dbRef.push().key!!
            val product = Product(id, name.text.toString(), price.text.toString().toDouble(), stock.text.toString().toInt())

            dbRef.child(id).setValue(product).addOnSuccessListener {
                Toast.makeText(this, "Produto adicionado com sucesso!", Toast.LENGTH_SHORT).show()
                finish()
            }
        }
    }
}
