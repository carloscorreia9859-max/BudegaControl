\# Budega Control 



Aplicativo Android criado como projeto acadêmico para a lanchonete \*\*Budega\*\*, localizada em frente ao Hospital Universitário.



\# Desenvolvido para

Cícero e Márcia Medeiros — proprietários da Budega, com gestão de vendas e estoque simplificada.



\# Funcionalidades

\- Tela de Login (usuário: admin / senha: 1234)

\- Controle de produtos e estoque

\- Cadastro local de novos produtos

\- Interface em português e armazenamento local



\# Como executar

1\. Abra o Android Studio.

2\. Clique em \*\*File > Open\*\* e selecione a pasta `BudegaControl`.

3\. Execute o app em um emulador ou dispositivo Android.



