package com.example.budegacontrol.models

data class Product(
    var id: String? = null,
    var name: String? = null,
    var price: Double = 0.0,
    var stock: Int = 0
)
