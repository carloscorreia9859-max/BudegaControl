package com.example.budegacontrol

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.FirebaseDatabase

class RegisterSaleActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register_sale)

        val idInput = findViewById<EditText>(R.id.etProductId)
        val qtyInput = findViewById<EditText>(R.id.etQuantity)
        val btnSell = findViewById<Button>(R.id.btnSell)

        btnSell.setOnClickListener {
            val id = idInput.text.toString()
            val qty = qtyInput.text.toString().toInt()
            val dbRef = FirebaseDatabase.getInstance().getReference("products").child(id)

            dbRef.get().addOnSuccessListener {
                val stock = it.child("stock").value.toString().toInt()
                if (qty <= stock) {
                    dbRef.child("stock").setValue(stock - qty)
                    Toast.makeText(this, "Venda registrada!", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this, "Estoque insuficiente!", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
